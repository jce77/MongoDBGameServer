const express = require('express');
const nodemailer = require('nodemailer');
const MongoClient = require('mongodb').MongoClient;
const bcrypt = require('bcrypt'); // For password hashing
//const { MongoClient } = require('mongodb');
const router = express.Router();

// MongoDB Connection Details
let mongoConfig;





// user-authentication.js
router.use((req, res, next) => {
    console.log("Middleware executed");
    mongoConfig = req.app.locals.mongoConfig;
    console.log("Middleware mongoConfig1:", mongoConfig);
    req.mongoUrl = mongoConfig.url;
    req.dbName = mongoConfig.dbName;
    console.log("Middleware req.mongoUrl=", req.mongoUrl);
    console.log("Middleware req.dbName=", req.dbName);
    next();
});
  
router.post('/register', async (req, res) => {
    // Access MongoDB connection details using `mongoConfig`
    const url = mongoConfig.url;
    const dbName = mongoConfig.dbName;
    console.log("Register route executed");
  });


// Example function that takes a parameter
const handleHighscores = (helloWorldValue) => {
  // Your logic using helloWorldValue
  console.log(`Function called with value: ${helloWorldValue}`);
};

module.exports = {
  handleHighscores
};



 // module.exports = (config) => {
 //   return (req, res, next) => {
 //     console.log("Middleware received config2:", config);
 //     req.app.locals.mongoConfig = config;
 //     next();
 //   };
 // };


/*
router.post('/register', async (req, res) => {
    console.log("Register route executed");
    const { username, password, email } = req.body;

    console.log("Running /register");
    console.log("username=" + username);
    console.log("password=" + password);
    console.log("email=" + email);


    // Access MongoDB connection details using `mongoConfig`
    const url = req.mongoUrl;
    const dbName = req.dbName;
    const accountsCollection = 'accounts';
    const verificationsCollection = 'verifications';
    console.log("url=", url);
    console.log("dbName=", dbName);


    try {
        

        // Connect to MongoDB
        const client = new MongoClient(url, { useUnifiedTopology: true });

        await client.connect();
        const db = client.db(dbName);

        // Check if the username or email already exists
        const existingUser = await db.collection(accountsCollection).findOne({
        $or: [{ username: username }, { email: email }]
        });

        if (existingUser) {
        // User or email already exists
        res.status(409).json({ error: 'Username or email already registered' });
        } else {
        // Hash the password before storing it
        const hashedPassword = await bcrypt.hash(password, 10);

        // Insert the new user into the 'accounts' collection
        await db.collection(accountsCollection).insertOne({
            username: username,
            password: hashedPassword,
            email: email,
            verified: 'N' // Default to not verified
        });

        // Generate verification code
        const verificationCode = generateVerificationCode();

        // Insert verification entry into the 'verifications' collection
        await db.collection(verificationsCollection).insertOne({
            email: email,
            code: verificationCode
        });

        // Send verification email
        sendVerificationEmail(email, verificationCode);

        res.status(201).json({ success: 'User registered successfully. Check your email for verification.' });
        }

        client.close();
    } catch (error) {
        console.error('Error during registration:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
    });

  function generateVerificationCode() {
    let code = '';
    for (let i = 0; i < 10; i++) {
      code += Math.floor(Math.random() * 10);
    }
    return code;
  }

function sendVerificationEmail(toEmail, verificationCode) {
    // Nodemailer setup
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'your-email@gmail.com',
        pass: 'your-email-password'
      }
    });
  
    const mailOptions = {
      from: 'your-email@gmail.com',
      to: toEmail,
      subject: 'Verification Code for Your Game',
      text: `Your verification code is: ${verificationCode}`
    };
  
    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error('Error sending email:', error);
      } else {
        console.log('Email sent:', info.response);
      }
    });
  }
  */


  